#!/usr/bin/env python3
"""
Simple FastAPI server for model inference.
"""

import os
import uvicorn
from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.responses import JSONResponse
import tempfile
from pathlib import Path

# Import the inference module
from inference import ModelInference

app = FastAPI(title="Speech Model API", version="1.0.0")

# Load model
model_path = Path(__file__).parent.parent
model = ModelInference(model_path)

@app.get("/")
async def root():
    return {"message": "Speech Model API", "model_info": model.get_model_info()}

@app.post("/predict")
async def predict(file: UploadFile = File(...)):
    """Predict intent from uploaded audio file."""
    try:
        # Save uploaded file temporarily
        with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as tmp_file:
            content = await file.read()
            tmp_file.write(content)
            tmp_path = tmp_file.name

        # Make prediction
        intent, confidence = model.predict(tmp_path)

        # Clean up
        os.unlink(tmp_path)

        return {
            "intent": intent,
            "confidence": float(confidence),
            "filename": file.filename
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/model-info")
async def model_info():
    """Get model information."""
    return model.get_model_info()

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
