#!/bin/bash
set -e

echo "Installing Twi Speech Model Package..."

# Check Python version
python3 -c "import sys; assert sys.version_info >= (3, 8)" || {
    echo "Error: Python 3.8+ required"
    exit 1
}

# Install dependencies
pip install -r requirements.txt

# Run tests
python -m pytest tests/ || echo "Warning: Some tests failed"

echo "Installation complete!"
echo "To start the API server, run: python -m deployable_twi_speech_model.utils.serve"
