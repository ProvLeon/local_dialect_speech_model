# API Documentation

## Authentication
No authentication required for this version.

## Rate Limiting
Currently no rate limiting implemented.

## Error Handling
All endpoints return appropriate HTTP status codes and error messages in JSON format.

## Audio Format Support
- Supported formats: WAV, MP3, FLAC
- Recommended: 16kHz WAV files
- Maximum duration: 30 seconds
