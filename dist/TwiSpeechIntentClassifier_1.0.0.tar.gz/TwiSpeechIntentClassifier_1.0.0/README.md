# TwiSpeechIntentClassifier

Advanced Twi speech intent recognition model trained on local dialect data with 49 intent classes for e-commerce applications

## Quick Start

```python
from deployable_twi_speech_model import SpeechModelPackage

# Load the model
model = SpeechModelPackage.from_pretrained(".")

# Make a prediction
intent, confidence = model.predict("path/to/audio.wav")
print(f"Intent: {intent}, Confidence: {confidence:.3f}")
```

## API Server

Start the API server:

```bash
python -m deployable_twi_speech_model.utils.serve
```

The server will be available at `http://localhost:8000`

## Endpoints

- `GET /health` - Health check
- `GET /model-info` - Model information
- `POST /test-intent` - Intent prediction from audio file

## Docker Deployment

```bash
docker build -t twispeechintentclassifier .
docker run -p 8000:8000 twispeechintentclassifier
```

## Version: 1.0.0
## Author: Local Dialect Speech Team
## License: MIT
